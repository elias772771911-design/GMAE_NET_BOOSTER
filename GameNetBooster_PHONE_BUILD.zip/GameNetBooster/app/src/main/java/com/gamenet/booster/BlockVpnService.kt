package com.gamenet.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local, on-device firewall mode. All app traffic except installed PUBG Mobile
 * package variants is routed into this VPN interface and discarded. PUBG is
 * explicitly excluded from the VPN and therefore keeps using the normal network.
 * No remote VPN server is used and no packet contents are uploaded.
 */
class BlockVpnService : VpnService() {
    companion object {
    const val ACTION_STOP = "com.gamenet.booster.STOP_BLOCKING"
    const val PREFS = "block_status"
    const val KEY_RUNNING = "running"
    private const val CHANNEL_ID = "game_net_blocker"
    private const val NOTIFICATION_ID = 71
    private val PUBG_PACKAGES = listOf(
        "com.tencent.ig",       // Global
        "com.pubg.krmobile",    // Korea
        "com.rekoo.pubgm",      // Taiwan
        "com.vng.pubgmobile"    // Vietnam
    )
    }

    private var tunnel: ParcelFileDescriptor? = null
    private val active = AtomicBoolean(false)
    private var reader: Thread? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        if (active.get()) return START_STICKY
        try {
            val installedPubg = PUBG_PACKAGES.filter { packageName ->
                try {
                    packageManager.getPackageInfo(packageName, 0)
                    true
                } catch (_: Exception) { false }
            }
            if (installedPubg.isEmpty()) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }

            val builder = Builder()
                .setSession("GAME NET BOOSTER - PUBG ONLY")
                .setMtu(1500)
                .addAddress("10.77.0.1", 32)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd77:77::1", 128)
                .addRoute("::", 0)

            // Excluded PUBG packages bypass the local VPN and retain normal internet access.
            installedPubg.forEach { builder.addDisallowedApplication(it) }
            tunnel = builder.establish()
            if (tunnel == null) throw IllegalStateException("VPN interface could not be created")

            active.set(true)
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, true).apply()
            startDiscardReader(tunnel!!)
        } catch (e: Exception) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_STICKY
    }

    private fun startDiscardReader(fd: ParcelFileDescriptor) {
        reader = Thread {
            val buffer = ByteArray(32767)
            try {
                FileInputStream(fd.fileDescriptor).use { input ->
                    while (active.get()) {
                        // Deliberately discard packets from blocked apps; do not forward or store them.
                        if (input.read(buffer) < 0) break
                    }
                }
            } catch (_: Exception) {
                // Closing the VPN descriptor while stopping is expected.
            }
        }.apply { name = "GameNetPacketDropper"; isDaemon = true; start() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "GAME NET BOOSTER", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("GAME NET BOOSTER يعمل")
            .setContentText("الإنترنت مسموح لـ PUBG فقط. أوقف الحجب من داخل التطبيق.")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setOngoing(true)
            .build()
    }

    override fun onRevoke() {
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        active.set(false)
        try { tunnel?.close() } catch (_: Exception) { }
        tunnel = null
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
