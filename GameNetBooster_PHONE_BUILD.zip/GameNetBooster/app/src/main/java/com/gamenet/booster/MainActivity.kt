package com.gamenet.booster

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.io.File
import java.util.Locale

/** GAME NET BOOSTER: user-controlled local per-app firewall and game launcher.
 * PUBG package variants bypass the local VPN; other app traffic is discarded locally.
 * This does not claim to increase FPS or guarantee lower ping.
 */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var info: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 3000)
        }
    }
    private val ice = Color.rgb(127, 214, 255)
    private val vpnRequestCode = 7401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 32)
        }
        content.addView(TextView(this).apply {
            text = "❄️ GAME NET BOOSTER"
            textSize = 25f
            setTextColor(ice)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        })
        status = TextView(this).apply {
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(12, 18, 12, 18)
            background = panel()
        }
        content.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18 })
        content.addView(makeButton("تشغيل وضع PUBG فقط - حجب بقية التطبيقات") { requestBlockMode() })
        content.addView(makeButton("إيقاف الحجب وإعادة الإنترنت للجميع") { stopBlockMode() })
        content.addView(makeButton("تشغيل PUBG MOBILE") { launchPubg() })
        content.addView(makeButton("تحديث معلومات الجهاز") { refresh() })
        content.addView(makeButton("تنظيف ملفات التطبيق المؤقتة") { cleanOwnCache() })
        content.addView(makeButton("إعدادات التخزين") {
            startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        })
        info = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.WHITE)
            setPadding(8, 22, 8, 8)
        }
        content.addView(info)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(5, 8, 15))
            addView(content)
        })
        refresh()
    }

    private fun panel() = GradientDrawable().apply {
        setColor(Color.rgb(16, 27, 43))
        cornerRadius = 24f
        setStroke(1, ice)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setTextColor(Color.BLACK)
        background = GradientDrawable().apply {
            setColor(ice)
            cornerRadius = 32f
        }
        layoutParams = LinearLayout.LayoutParams(-1, 66).apply { bottomMargin = 14 }
        setOnClickListener { action() }
    }


    private fun requestBlockMode() {
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            startActivityForResult(prepareIntent, vpnRequestCode)
        } else {
            startBlockService()
        }
    }

    private fun startBlockService() {
        val intent = Intent(this, BlockVpnService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this, "جارٍ تشغيل وضع PUBG فقط", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر تشغيل الحجب. تحقق من إذن VPN", Toast.LENGTH_LONG).show()
        }
        handler.postDelayed({ refresh() }, 700)
    }

    private fun stopBlockMode() {
        stopService(Intent(this, BlockVpnService::class.java))
        getSharedPreferences(BlockVpnService.PREFS, MODE_PRIVATE).edit()
            .putBoolean(BlockVpnService.KEY_RUNNING, false).apply()
        Toast.makeText(this, "تم إيقاف الحجب وإعادة الاتصال للتطبيقات", Toast.LENGTH_LONG).show()
        refresh()
    }

    @Deprecated("Deprecated by Android; retained for compatibility with the current project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == vpnRequestCode) {
            if (resultCode == RESULT_OK) startBlockService()
            else Toast.makeText(this, "لم يتم منح إذن VPN؛ لم يتم تفعيل الحجب", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchPubg() {
        val packageName = "com.tencent.ig"
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent == null) {
            Toast.makeText(this, "لعبة PUBG MOBILE GLOBAL غير مثبتة على الجهاز", Toast.LENGTH_LONG).show()
            return
        }
        getSharedPreferences("stats", MODE_PRIVATE).edit()
            .putInt("launches", getSharedPreferences("stats", MODE_PRIVATE).getInt("launches", 0) + 1)
            .apply()
        try {
            startActivity(launchIntent)
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر فتح اللعبة", Toast.LENGTH_SHORT).show()
        }
        refresh()
    }

    private fun fileSize(file: File?): Long {
        if (file == null || !file.exists()) return 0L
        if (file.isFile) return file.length()
        return (file.listFiles() ?: emptyArray()).sumOf { fileSize(it) }
    }

    private fun cacheBytes(): Long = fileSize(cacheDir) + fileSize(externalCacheDir)

    private fun cleanOwnCache() {
        // Only this app's private cache is touched. PUBG data and other apps are never modified.
        listOfNotNull(cacheDir, externalCacheDir).forEach { dir ->
            dir.listFiles()?.forEach { child -> child.deleteRecursively() }
        }
        Toast.makeText(this, "تم تنظيف الملفات المؤقتة الخاصة بالتطبيق فقط", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun connectionLabel(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "غير متصل بالإنترنت"
        val caps = cm.getNetworkCapabilities(network) ?: return "حالة الاتصال غير معروفة"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "متصل عبر Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "متصل عبر بيانات الهاتف"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "متصل عبر Ethernet"
            else -> "متصل بالشبكة"
        }
    }

    private fun refresh() {
        if (!::status.isInitialized || !::info.isInitialized) return
        val blocking = getSharedPreferences(BlockVpnService.PREFS, MODE_PRIVATE)
            .getBoolean(BlockVpnService.KEY_RUNNING, false)
        status.text = "حالة الشبكة: ${connectionLabel()}\n" +
            if (blocking) "وضع الحجب: نشط - PUBG فقط مسموح لها بالإنترنت" else "وضع الحجب: متوقف - جميع التطبيقات تستخدم الإنترنت"
        status.setTextColor(if (blocking) Color.rgb(111, 230, 153) else ice)

        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memory)
        val stat = StatFs(filesDir.path)
        val freeStorageGb = stat.availableBytes / 1_000_000_000.0
        val batteryTemp = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val tempText = if (batteryTemp < 0) "غير متاح" else String.format(Locale.US, "%.1f °C", batteryTemp / 10.0)
        val launches = getSharedPreferences("stats", MODE_PRIVATE).getInt("launches", 0)
        info.text = "معلومات الجهاز\n" +
            "الذاكرة المتاحة: ${memory.availMem / 1_048_576} MB من ${memory.totalMem / 1_048_576} MB\n" +
            String.format(Locale.US, "التخزين المتاح: %.1f GB\n", freeStorageGb) +
            String.format(Locale.US, "ملفات GAME NET المؤقتة: %.2f MB\n", cacheBytes() / 1_048_576.0) +
            "حرارة البطارية: $tempText\n" +
            "الجهاز: ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE}\n" +
            "مرات تشغيل PUBG من التطبيق: $launches\n\n" +
            "ملاحظة: التطبيق لا يغيّر إعدادات اللعبة ولا يضمن زيادة FPS أو خفض Ping."
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refreshTask)
        handler.post(refreshTask)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshTask)
        super.onPause()
    }
}
